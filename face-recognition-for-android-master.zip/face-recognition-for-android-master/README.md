# face-recognition-for-android

Haarcascades for face detection and LBPH approach for a face recognition.
First num is similarity (the less the better) with trained person face while second is average value of 20 last similarity metrics (first value).
